import numpy as np
import os
from tensorflow.keras.datasets import cifar10, fashion_mnist
import timeit
import matplotlib.pyplot as plt
# from load_label_data import *
import os
import json
from tensorflow.keras.preprocessing.image import ImageDataGenerator

label_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
data_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/Test/"
path  = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/MASKS/"

label_dir = "F:/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
data_dir = "F:/Projects/MASKS/Fruit-Images-Dataset/Test/"
path  = "F:/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
Project_path  = "F:/Projects/MASKS/Fruit-Images-Dataset/MASKS/"

datagen = ImageDataGenerator()
test_it = datagen.flow_from_directory(
                            data_dir, 
                            seed=123)
print(test_it.class_indices)
print(len(test_it.class_indices))


def load_labels():
    all_labels = {}
    label_arr = []
    for _class_name in os.listdir(data_dir):
        for _file in os.listdir(data_dir+_class_name):
            label_arr.append(test_it.class_indices[_class_name])
    return label_arr

# (input_train, target_train), (input_test, target_test) = fashion_mnist.load_data()
target_test = load_labels()
class_no = len(test_it.class_indices)
print(target_test[:100])

agent_counter = 0

predictions = []
for j in range(len(target_test)):
    predictions.append([i for i in range(class_no)])
agent_counter = 0
results = []
votes = []
for i in range(len(target_test)):
    votes.append({})
    for j in range(class_no):
        votes[i][j] = 0
start_interval = timeit.default_timer()
for i in range(len(target_test)):
    votes.append({})
    for j in range(class_no):
        votes[i][j] = 0
for dirr in os.listdir(path+"Results"):
    np_array = np.load(path+"Results"+"/"+dirr)
    agent_counter +=1 
    correct_answer = 0
    wrong_answer = 0
    conflict_answer = 0
    correct_assist = 0
    wrong_assist = 0
    for i in range(len(target_test)):
        votes[i][np_array[i*51]] += 1
        max_vote_no = 0
        max_vote_index = []

        for j in range(class_no):
            if votes[i][j] > max_vote_no:
                max_vote_no = votes[i][j]
                max_vote_index = [j]
            elif votes[i][j] == max_vote_no:
                max_vote_index.append(j)
        # print("max_vote_index")
        # print(max_vote_index)
        # print("votes[i][j]")
        # print(votes[i][j])
        # break
        if not len(max_vote_index):
            conflict_answer += 1
        elif len(max_vote_index) == 1:
            if max_vote_index[0] == target_test[i]:
                correct_answer += 1
            else:
                wrong_answer += 1
                # plt.figure(figsize=(10,10))
                # plt.xticks([])
                # plt.yticks([])
                # plt.grid(False)
                # plt.imshow(input_test[i])
                # plt.xlabel("agent_counter-"+str(agent_counter)+"-instance-"+str(i)+"-"+class_names[predictions[i][0]]+"-but it is-"+class_names[target_test[i]])
                # plt.show()
        else:
            if target_test[i] in max_vote_index:
                correct_assist += 1
            else:
                wrong_assist += 1
    # with open("FasionMnistAg
    # break
    results.append({
        "agent_counter" : agent_counter,
        "correct_answer" : correct_answer,
        "wrong_answer" : wrong_answer,
        "conflict_answer" : conflict_answer,
        "correct_assist" : correct_assist,
        "wrong_assist" : wrong_assist})
    stop_interval = timeit.default_timer() 
    print("single agent Time Passed --------------------------------------------------------------------")
    print(stop_interval-start_interval)
    print(agent_counter)
stop_interval = timeit.default_timer() 
print("all agent Time Passed --------------------------------------------------------------------")
print(stop_interval-start_interval)
print(str(results).replace("},", "},\n"))
with open(Project_path+"VotingAgentPredictions.txt","w") as f:
    f.write(str(results))




vote_tresh = 0.99
for vote_tresh_10 in range(1, 5):
    vote_tresh = vote_tresh_10/100.0
    agent_counter = 0

    predictions = []
    for j in range(len(target_test)):
        predictions.append([i for i in range(class_no)])
    agent_counter = 0
    results = []
    votes = []
    for i in range(len(target_test)):
        votes.append({})
        for j in range(class_no):
            votes[i][j] = 0
    for dirr in os.listdir(path+"Results"):
        np_array = np.load(path+"Results"+"/"+dirr)
        agent_counter +=1 
        correct_answer = 0
        wrong_answer = 0
        conflict_answer = 0
        correct_assist = 0
        wrong_assist = 0
        for i in range(len(target_test)):
            votes[i][np_array[i*51]] += 1
            max_vote_no = 0
            max_vote_index = []

            for j in range(class_no):
                if votes[i][j] > max_vote_no:
                    max_vote_no = votes[i][j]
                    max_vote_index = [j]
                elif votes[i][j] == max_vote_no:
                    max_vote_index.append(j)
            # print("max_vote_index")
            # print(max_vote_index)
            # print("votes[i][j]")
            # print(votes[i][j])
            # break
            if not len(max_vote_index):
                conflict_answer += 1
            elif len(max_vote_index) == 1 and votes[i][max_vote_index[0]]>=agent_counter*vote_tresh:
                if max_vote_index[0] == target_test[i]:
                    correct_answer += 1
                else:
                    wrong_answer += 1
                    # plt.figure(figsize=(10,10))
                    # plt.xticks([])
                    # plt.yticks([])
                    # plt.grid(False)
                    # plt.imshow(input_test[i])
                    # plt.xlabel("agent_counter-"+str(agent_counter)+"-instance-"+str(i)+"-"+class_names[predictions[i][0]]+"-but it is-"+class_names[target_test[i]])
                    # plt.show()
            else:
                if target_test[i] in max_vote_index:
                    correct_assist += 1
                else:
                    wrong_assist += 1
        # with open("FasionMnistAg
        # break
        results.append({
            "agent_counter" : agent_counter,
            "correct_answer" : correct_answer,
            "wrong_answer" : wrong_answer,
            "conflict_answer" : conflict_answer,
            "correct_assist" : correct_assist,
            "wrong_assist" : wrong_assist})
        stop_interval = timeit.default_timer() 
        print("single agent Time Passed --------------------------------------------------------------------")
        print(stop_interval-start_interval)
        print(agent_counter)
    stop_interval = timeit.default_timer() 
    print("all agent Time Passed --------------------------------------------------------------------")
    print(stop_interval-start_interval)
    print(str(results).replace("},", "},\n"))
    with open(Project_path+str(vote_tresh)+"VotingAgentPredictions.txt","w") as f:
        f.write(str(results))
