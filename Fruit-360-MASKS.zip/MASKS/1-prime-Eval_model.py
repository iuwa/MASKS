import tensorflow as tf

from tensorflow.keras import  layers, models
import matplotlib.pyplot as plt
import gc
from PIL import Image
from tensorflow.keras.datasets import cifar10, cifar100, fashion_mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten, Conv2D, MaxPooling2D
from tensorflow.keras.losses import sparse_categorical_crossentropy
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt
from tensorflow import keras
import random
import timeit
import os
# from build_noise import *
from tensorflow.keras import backend as K
from class_build_noise import *
import cv2
import json
import platform
print(platform.system())



# from tensorflow.compat.v1 import ConfigProto
# from tensorflow.compat.v1 import InteractiveSession
# config = ConfigProto()
# config.gpu_options.allow_growth = True
# session = InteractiveSession(config=config)

# force on CPU
# import os
# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"   # see issue #152
# os.environ["CUDA_VISIBLE_DEVICES"] = ""
# force on CPU

gpus = tf.config.experimental.list_physical_devices('GPU')
print("_________________________GPUS____________________")
print(gpus)
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

start_interval_all = timeit.default_timer()
# Model configuration
if platform.system() == "Windows":
    path = "F:/Projects/MASKS/Fruit-Images-Dataset/MASKS/Models/"
    project_path = "F:/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
    data_dir = "F:/Projects/MASKS/Fruit-Images-Dataset/Test/"
    temp_dir = "F:/Projects/MASKS/Fruit-Images-Dataset/Test/Cherry Wax Red/"
else:
    path = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/MASKS/Models/"
    project_path = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
    data_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/Test/"
    # data_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/Training/"
    temp_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/Test/Cherry Wax Red/"
batch_size = 1
img_width, img_height, img_num_channels = 100, 100, 3
loss_function = sparse_categorical_crossentropy
no_classes = 10
no_epochs = 75
optimizer = Adam()
validation_split = 0.2
verbosity = 1
input_shape = (img_width, img_height, img_num_channels)


datagen = ImageDataGenerator()
test_it = datagen.flow_from_directory(
                            data_dir, 
                            batch_size=batch_size, 
                            target_size = (img_width, img_height), 
                            seed=123)
print(test_it.class_indices)

# class_labels = {"Apple":0, "Apricot":1, }

stop_interval = timeit.default_timer() 
print("model Time Passed --------------------------------------------------------------------")
print(stop_interval-start_interval_all)
print("getting neighborhood")



stop_interval = timeit.default_timer() 
print("model Time Passed --------------------------------------------------------------------")
print(stop_interval-start_interval_all)
print("getting predictions-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-")
randInt = []
cc = 0
conflicts = {}
for dirr in os.listdir(path):
    print("load_model --------------------------------------------------------------------")
    model = keras.models.load_model(path+'/'+dirr)
    step_size = 1
    cpu_res = []
    results = np.array([])
    start_interval = timeit.default_timer()
    accu = 0
    nacu = 0

    for _class_name in os.listdir(data_dir):
        for _file in os.listdir(data_dir+_class_name):
            start_intervala = timeit.default_timer() 
            if _file.split(".")[-1] == "jpg":
                np_image = Image.open(data_dir+_class_name+"/"+_file)
                np_image = np.array(np_image).astype('float32')/255
                np_image = np.expand_dims(np_image, axis=0)
                neigh_man = NeighMan(dir_data=project_path, input_shape=input_shape, output_shape=np_image.shape)
                input_test_nm = neigh_man.get_neighborhood_manipulations_from_image(np_image)
                # temp_pre0 = model.predict(np.vstack(input_test_nm))
                temp_pre = np.argmax(model.predict(np.vstack(input_test_nm)), axis=1)
                cpu_res += list(temp_pre)
                for _i in test_it.class_indices:
                    if temp_pre[0] == test_it.class_indices[_i]:
                        print("cpu")
                        print(_i)
                        print(_class_name)
                        if _i == _class_name:
                            accu += 1
                        else:
                            if _i+"+"+_class_name in conflicts:
                                conflicts[_i+"+"+_class_name] += 1
                            else:
                                conflicts[_i+"+"+_class_name] = 1
                        break
                nacu += 1
        
            print("=-==--=-132222222222222222222222222222222222222222222222222222")
            print(accu/nacu)
            print(accu)
            print(nacu)
            print("=-==--=-132222222222222222222222222222222222222222222222222222")
            print("single batch model Time Passed --------------------------------------------------------------------")
            stop_intervala = timeit.default_timer()
            print(stop_intervala-start_intervala)
            print("all batch model Time Passed --------------------------------------------------------------------")
            stop_intervala = timeit.default_timer()
            print(stop_intervala-start_interval_all)
    del model
    results = np.asarray(cpu_res)
    print("=-==--=-1111111111111111111111111111111111111111111111111111111111111111111")
    print(accu/nacu)
    print(accu)
    print(nacu)
    print("=-==--=-11111111111111111111111111111111111111111111111111111111111111111111111")
    print(results)
    print(results.shape)
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    # out_classes = np.reshape(np.argmax(results, axis=1), (-1, noise_counter+1))
    print(str(cc)+"-")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    print("reshape --------------------------------------------------------------------")
    stop_interval = timeit.default_timer() 
    print("all model Time Passed --------------------------------------------------------------------")
    print(stop_interval-start_interval)
    print("All Time Passed --------------------------------------------------------------------")
    print(stop_interval-start_interval_all)
    print("I --------------------------------------------------------------------")
    np.save(project_path+"Results/"+dirr+"-"+str(cc)+"-"+str(accu/nacu)+"-", results)# out_classes
    cc += 1

f = open("conflicts.json", "w+")
f.write(json.dumps(conflicts))
f.close()


