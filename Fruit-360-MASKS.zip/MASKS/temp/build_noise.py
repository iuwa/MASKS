
import numpy as np
from load_test_data import *

amount = 0.04
noise_counter = 50 # 100
all_salts = []
all_pepper = []
s_vs_p = 0.5
noise_size = 224
input_shape = (224, 224)


print(amount)
print(noise_size)
print(s_vs_p)
num_salt = np.ceil(amount * noise_size * s_vs_p)
num_peper = np.ceil(amount* noise_size  * (1. - s_vs_p))
for i in range(noise_counter):
    all_salts.append([np.random.randint(0, i-1, int(num_salt))  for i in input_shape])
    all_pepper.append([np.random.randint(0, i-1, int(num_peper))  for i in input_shape])
fs = open("FashionNoiseSalt.txt", "w+")
fp = open("FashionNoisePeper.txt", "w+")
fs.write(str(all_salts))
fp.write(str(all_pepper))
fs.close()
fp.close()


def sp_noisy(noise_typ,image, noise_counter):
    out = [image]
    for i in range(noise_counter):
        outTemp = np.copy(image)
        outTemp[all_salts[i]] = 1
        # Pepper mode
        outTemp[all_pepper[i]] = 0
        out.append(outTemp)
    return out




def get_neighborhood_manipulations(noise_counter, start=0, end=-1):
    manips = []
    counter = 0
    input_test = load_test_data(start=start, end=end)

    for it in input_test:
        # print(counter)
        manips+=sp_noisy("s&p",it, noise_counter)
        counter += 1
    # return np.asarray(manips)
    return manips