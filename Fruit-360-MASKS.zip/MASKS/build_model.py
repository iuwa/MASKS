
from tensorflow.keras.layers import RandomRotation, RandomFlip, RandomZoom, Dense, Flatten, Conv2D, MaxPooling2D, Convolution2D, Activation, Dropout, GlobalAveragePooling2D
import random
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input

input_shape = (100, 100, 3)
no_classes = 131

def build_model(randInt = [], 
                loss = "categorical_crossentropy", 
                optimizer = "adam", 
                metrics = "accuracy",
                no_classes = no_classes):
    randInt.append(random.randint(64,256)) # 0
    randInt.append(random.randint(32,128)) # 1
    randInt.append(random.randint(32,128)) # 2
    randInt.append(random.randint(32,128)) # 3
    randInt.append(random.randint(32,128)) # 4
    randInt.append(random.randint(16,64)) # 5
    randInt.append(random.randint(8,32)) # 6
    base_model = VGG16(
        weights = "imagenet", 
        input_shape = input_shape,
        include_top = False
    )
    randInt.append(random.randint(0,4)) # 7
    if not randInt[7]:
        for layers in base_model.layers:
            layers.trainable = False
    else:
        for layers in base_model.layers[:-1*randInt[7]]:
            layers.trainable = False

    model = Sequential(
        [
            base_model,
            GlobalAveragePooling2D(),
            Dense(randInt[0], activation = "relu"),
            Dropout(0.4),
            Dense(randInt[1], activation = "relu"),
            # Dropout(0.2),
            # Dense(randInt[2], activation = "relu"),
            # Dropout(0.2),
            # Dense(randInt[3], activation = "relu"),
            # Dropout(0.2),
            # Dense(randInt[4], activation = "relu"),
            Dropout(0.2),
            Dense(randInt[5], activation = "relu"),
            Dropout(0.2),
            Dense(randInt[6], activation = "relu"),
            Dense(no_classes, activation = "softmax")
        ]
    )
    print(model.summary())
    model.compile(loss = loss, optimizer = optimizer, metrics = metrics)  
    return model, randInt


def define_model(randInt = [], 
                loss = "categorical_crossentropy", 
                optimizer = "adam", 
                metrics = "accuracy",
                no_classes = no_classes):
    model = Sequential()
    layer_no = 11
    for _ in range(layer_no):
        randInt.append(random.randint(32,256))
    # randInt.append(random.randint(48,196))
    # randInt.append(random.randint(32,128))
    # randInt.append(random.randint(32,128))
    # randInt.append(random.randint(24,96))
    # randInt.append(random.randint(24,96))
    # randInt.append(random.randint(16,64))
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Conv2D(randInt[0], (3, 3), activation='relu'))
    model.add(layers.Conv2D(randInt[1], (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Conv2D(randInt[2], (3, 3), activation='relu'))
    model.add(layers.Conv2D(randInt[3], (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Conv2D(randInt[4], (3, 3), activation='relu'))
    model.add(layers.Conv2D(randInt[5], (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Flatten())
    # model.add(layers.Dropout(0.15))
    model.add(layers.Dense(randInt[6], activation='relu'))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Dense(randInt[7], activation='relu'))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Dense(randInt[8], activation='relu'))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Dense(randInt[9], activation='relu'))
    # model.add(layers.Dropout(0.15))
    model.add(layers.Dense(randInt[10], activation='relu'))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(no_classes, activation='softmax'))
    print(model.summary())
    model.compile(loss = loss, optimizer = optimizer, metrics = metrics)
    print(model)
    return model, randInt