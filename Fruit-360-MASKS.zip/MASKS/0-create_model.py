from load_input_data import *
from build_model import *

# force on CPU
# import os
# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"   # see issue #152
# os.environ["CUDA_VISIBLE_DEVICES"] = ""
# force on CPU



# Model configuration
batch_size = 400
loss_function = sparse_categorical_crossentropy
no_classes = 131
no_epochs = 60
optimizer = Adam()
validation_split = 0.2
verbosity = 1
model_no = 1000
image_size = (100, 100)
FILES = "../"

train_data, validation_data = load_input_data(batch_size=batch_size)
input_shape = (100, 100, 3)

tf.keras.backend.clear_session()

start_interval_all = timeit.default_timer()
for i in range(model_no):
    start_interval = timeit.default_timer()
    randInt = []
    # model, randInt = build_model(randInt=randInt)
    model, randInt = define_model(randInt=randInt)
    print("randInt---------------------------------------------")
    print(randInt)
    # model, randInt = define_model(randInt=randInt)
    
    history = model.fit(
        train_data, 
        epochs = no_epochs,
        steps_per_epoch = train_data.samples // batch_size,
        validation_data = validation_data, 
        validation_steps = validation_data.samples // batch_size,
    )
    print("Test ====================================================================")
    print(history.history['accuracy'])
    print(model.metrics_names)
    print("Train ====================================================================")
    print("End ====================================================================")
    tempStr = ""
    for j in randInt:
        tempStr += str(j) + "-"
    modelName = "000st-"+str(i)+"s-"+str(history.history['accuracy'][-1])+"-l-"+tempStr
    model.save("Models/"+modelName)    

    del model
    stop_interval = timeit.default_timer()  
    print("TIME -----------------------------------------------------------------")
    print(stop_interval-start_interval)
    print("Time Passed --------------------------------------------------------------------")
    print(stop_interval-start_interval_all)
    print("I --------------------------------------------------------------------")
