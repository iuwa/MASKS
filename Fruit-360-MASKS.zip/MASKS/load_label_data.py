import os
import json
from tensorflow.keras.preprocessing.image import ImageDataGenerator

label_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/MASKS/"
data_dir = "/media/iuwa/New Volume/Projects/MASKS/Fruit-Images-Dataset/Test/"


datagen = ImageDataGenerator()
test_it = datagen.flow_from_directory(
                            data_dir, 
                            seed=123)
print(test_it.class_indices)


def load_labels():
    all_labels = {}
    label_arr = []
    for _class_name in os.listdir(data_dir):
        for _file in os.listdir(data_dir+_class_name):
            label_arr.append(test_it.class_indices[_class_name])
    return label_arr