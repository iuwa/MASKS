import tkinter as tk
from tkinter import filedialog
from tkinter import *
from typing import Counter
from PIL import ImageTk, Image
import numpy
from keras.models import load_model
import os
import json

data_dir = "/media/iuwa/New Volume/Projects/MASKS/CatDog/test/test1/"

label_dir = "/media/iuwa/New Volume/Projects/MASKS/CatDog/test/"

# model = load_model('model1_catsVSdogs_10epoch.h5')
#dictionary to label all traffic signs class.
classes = { 
    0:'its a cat',
    1:'its a dog',
 
}
#initialise GUI
top=tk.Tk()
top.geometry('1200x1200')
top.title(' ')
top.configure(background='#CDCDCD')
label=Label(top,background='#CDCDCD', font=('arial',15,'bold'))
sign_image = Label(top)
# def classify(file_path):
#     global label_packed
#     image = Image.open(file_path)
#     image = image.resize((128,128))
#     image = numpy.expand_dims(image, axis=0)
#     image = numpy.array(image)
#     image = image/255
#     pred = model.predict_classes([image])[0]
#     sign = classes[pred]
#     print(sign)
#     label.configure(foreground='#011638', text=sign) 

if "test1.json" in os.listdir(label_dir):
    with open(label_dir+'test1.json') as json_file:
        all_labels = json.load(json_file)
    print(all_labels)
else:
    all_labels = {}
counter = 0
dir_list = os.listdir(data_dir)


def its_cat():
    global counter
    global dir_list
    all_labels[dir_list[counter]] = "cat"
    counter += 1
    with open(label_dir+"test1.json", 'w') as outfile:
        json.dump(all_labels, outfile)
    upload_image()


def its_dog():
    global counter
    global dir_list
    all_labels[dir_list[counter]] = "dog"
    counter += 1
    with open(label_dir+"test1.json", 'w') as outfile:
        json.dump(all_labels, outfile)
    upload_image()
    

def show_classify_button():
    classify_cat=Button(top,text="CAT",
                    command=lambda: its_cat(),
                    padx=10,pady=5)
    classify_cat.configure(
                    background='#364156', 
                    foreground='white',
                    font=('arial',40,'bold'))
    classify_cat.place(relx=0.51,rely=0.13)
    classify_dog=Button(top,text="DOG",
                    command=lambda: its_dog(),
                    padx=10,pady=5)
    classify_dog.configure(
                    background='#364156', 
                    foreground='white',
                    font=('arial',40,'bold'))
    classify_dog.place(relx=0.34,rely=0.13)


def upload_image():
    global counter
    while dir_list[counter] in all_labels:
        counter += 1
    uploaded=Image.open(data_dir+dir_list[counter])
    uploaded.thumbnail(((top.winfo_width()/2.25),
                (top.winfo_height()/2.25)))
    im=ImageTk.PhotoImage(uploaded.resize((700, 700)))
    sign_image.configure(image=im)
    sign_image.image=im
    label.configure(text=dir_list[counter])
    show_classify_button()
    print(all_labels)
    print(counter)
    

upload=Button(top,text="Upload an image",command=upload_image,padx=10,pady=10)
upload.configure(background='#364156', foreground='white',font=('arial',10,'bold'))
upload.pack(padx=0,pady=50)
sign_image.pack(side=BOTTOM,expand=True)
label.pack(side=BOTTOM,expand=True)
heading = Label(top, text=" ",pady=20, font=('arial',20,'bold'))
heading.configure(background='#CDCDCD',foreground='#364156')
heading.pack()
top.mainloop()